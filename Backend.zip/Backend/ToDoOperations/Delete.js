
export const DeleteTodo = (todo, id) => {

    // let todo = []

    // todo.push({
    //     id: 1,
    //     title: "Wake up",
    //     description: "Wake up in the morning!"
    // })
    // todo.push({
    //     id: 2,
    //     title: "Slee up",
    //     description: "Sleep at night!"
    // })

    if(todo.length == 0)
        return []
    // console.log("todo: ", todo)
    for (let i = 0; i < todo.length; i++) {
        if(id == todo[i].id){
            delete todo.splice(i, 1)
            break
        }
    }
    return todo
    
}