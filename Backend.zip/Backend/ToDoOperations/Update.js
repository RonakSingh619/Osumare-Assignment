
export const UpdateTodo = (todo, id, newTitle, newDescription) => {

    // let todo = []

    // todo.push({
    //     id: 1,
    //     title: "Wake up",
    //     description: "Wake up in the morning!"
    // })
    // todo.push({
    //     id: 2,
    //     title: "Slee up",
    //     description: "Sleep at night!"
    // })
    // console.log("todo: ", todo)
    for (let i = 0; i < todo.length; i++) {
        if(id == todo[i].id){
            // console.log("Match found at index: ",i)
            todo[i].title = newTitle
            todo[i].description = newDescription
        }
    }
    return todo
    
}