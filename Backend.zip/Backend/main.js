//  Imports
import cors from 'cors'
import express from 'express'
import { fileURLToPath } from 'url'
import { dirname, join } from 'path'
import { GetTodoById } from './ToDoOperations/readById.js'
import { UpdateTodo } from './ToDoOperations/Update.js'
import { DeleteTodo } from './ToDoOperations/Delete.js'


// Server setup
let port = 3000
let app = express()
app.use(express.json())
app.use(cors({
    origin: ['http://localhost:5173'],
    credentials: true,
    methods: 'GET,POST,DELETE,PUT',
    allowedHeaders: 'Content-Type, Authorization'
}))

const __filename = fileURLToPath(import.meta.url)
const __dirname = dirname(__filename)

// ---------------------- Todo Initialization ----------------------
const todo = []
let TodoId = 1

// ---------------------- APIs ----------------------

// Retrieve a list of all tasks. 
app.get('/tasks', (req, res)=>{
    try {
        res.json({ data: todo, msg: "", bool: true })
    } catch (error) {
        res.status(500).json({ Error: String(error) })
    }
})

// Retrieve a specific task by ID.
app.get('/tasks/:id', (req, res)=>{
    try {
        const { id } = req.params
        console.log("id: ", id)
        const todoObj = GetTodoById(todo, id)
        res.json({ data: todoObj, msg: "", bool: true })
    } catch (error) {
        res.status(500).json({ Error: String(error) })
    }
})

// Create a new task. 
app.post('/tasks', (req, res)=>{
    try {
        const { title, desc } = req.body
        console.log("desc: ", desc)
        todo.push({
            id: TodoId,
            title: title,
            description: desc
        })
        TodoId++
        // console.log("newly created todo: ", title)
        res.json({ data: todo, msg: "Todo added successfully", bool: true })
    } catch (error) {
        res.status(500).json({ Error: String(error) })
    }
})

// Update an existing task by ID. 
app.put('/tasks/:id', (req, res)=>{
    try {
        const {id} = req.params
        const { title, desc } = req.body
        const updatedTodo = UpdateTodo(todo, id, title, desc)
        res.json({ data: updatedTodo, msg: "", bool: true })
    } catch (error) {
        console.log("Err in put",error);
        
        res.status(500).json({ Error: String(error) })
    }
})

// Delete a task by ID. 
app.delete('/tasks/:id', (req, res)=>{
    try {
        const {id} = req.params
        const deletedTodo = DeleteTodo(todo, id)
        console.log("deleted Todo: ", deletedTodo)
        res.json({ data: todo, msg: "", bool: true })
    } catch (error) {
        res.status(500).json({ Error: String(error) })
    }
})

// ---------------------- Handling invalid API endpoints ----------------------

app.use('/tasks', (req, res)=>{
    res.status(500).send(`The method ${req.method} is not compatible with /tasks' !!`)
})

app.use('/tasks/:id', (req, res)=>{
    res.status(500).send(`The method ${req.method} is not compatible with /tasks/:id !!`)
})

app.use('/tasks', (req, res)=>{
    res.status(500).send(`The method ${req.method} is not compatible with /tasks' !!`)
})

app.use('/tasks/:id', (req, res)=>{
    res.status(500).send(`The method ${req.method} is not compatible with /tasks/:id !!`)
})

app.use('/tasks/:id', (req, res)=>{
    res.status(500).send(`The method ${req.method} is not compatible with /tasks/:id !!`)
})

app.use((req, res)=>{
    res.status(404).send("Route Not Found!")
})


// Server Listener
app.listen(port, '0.0.0.0', () => {
    console.log(`Server ON url: http://localhost:${port}`)
})